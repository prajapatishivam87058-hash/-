package com.padhai.notes;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends Activity {

    private static final int REQ_FILE = 101;
    private static final int REQ_BACKUP = 102;
    private static final int REQ_PICK = 103;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingBackup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        webView.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        webView.setBackgroundColor(Color.parseColor("#FFF7E6"));
        setContentView(webView);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(false);
        ws.setSupportZoom(false);
        ws.setBuiltInZoomControls(false);
        ws.setTextZoom(100);

        webView.addJavascriptInterface(new Bridge(), "Android");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // बाहर की कोई भी वेबसाइट नहीं खुलेगी
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                    filePathCallback = null;
                }
                filePathCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    filePathCallback.onReceiveValue(null);
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl("file:///android_asset/index.html");
        }
    }

    // ---------- JavaScript से बात करने वाला पुल ----------
    private class Bridge {

        private File fileFor(String key) {
            if (key == null || !key.matches("[a-z.]{1,20}")) return null;
            if (key.endsWith(".bak")) {
                // "data.bak" = "data" की पिछली सेव की हुई कॉपी
                String base = key.substring(0, key.length() - 4);
                if (!base.matches("[a-z]{1,20}")) return null;
                return new File(getFilesDir(), "pn_" + base + ".json.bak");
            }
            if (key.indexOf('.') >= 0) return null;
            return new File(getFilesDir(), "pn_" + key + ".json");
        }

        @JavascriptInterface
        public synchronized String load(String key) {
            File f = fileFor(key);
            if (f == null || !f.exists()) return "";
            try (InputStream in = new FileInputStream(f)) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                return new String(out.toByteArray(), StandardCharsets.UTF_8);
            } catch (IOException e) {
                return "";
            }
        }

        @JavascriptInterface
        public synchronized boolean save(String key, String value) {
            if (key != null && key.endsWith(".bak")) return false;
            File f = fileFor(key);
            if (f == null || value == null) return false;
            File tmp = new File(getFilesDir(), f.getName() + ".tmp");
            try (OutputStream out = new FileOutputStream(tmp)) {
                out.write(value.getBytes(StandardCharsets.UTF_8));
                out.flush();
            } catch (IOException e) {
                tmp.delete();
                return false;
            }
            // पुरानी फाइल को .bak में रखो, फिर नई को जगह दो
            File bak = new File(getFilesDir(), f.getName() + ".bak");
            if (f.exists()) {
                if (bak.exists()) bak.delete();
                f.renameTo(bak);
            }
            if (!tmp.renameTo(f)) {
                if (bak.exists() && !f.exists()) bak.renameTo(f);
                tmp.delete();
                return false;
            }
            return true;
        }

        @JavascriptInterface
        public void setBarColor(final String hex) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        getWindow().setStatusBarColor(Color.parseColor(hex));
                    } catch (Exception ignored) {
                    }
                }
            });
        }

        // लाइब्रेरी: फोन से वीडियो / PDF / फोटो चुनना (फाइल कॉपी नहीं होती, सिर्फ़ याद रखी जाती है)
        @JavascriptInterface
        public void pickFiles() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                            | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    try {
                        startActivityForResult(i, REQ_PICK);
                    } catch (Exception e) {
                        callJs("window.onFilesPicked && window.onFilesPicked('[]')");
                    }
                }
            });
        }

        // लाइब्रेरी की फाइल को फोन के अपने प्लेयर / PDF ऐप में खोलना
        @JavascriptInterface
        public void openFile(final String uri, final String mime) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_VIEW);
                        String m = (mime == null || mime.length() == 0) ? "*/*" : mime;
                        i.setDataAndType(Uri.parse(uri), m);
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(i);
                    } catch (Exception e) {
                        callJs("window.onOpenResult && window.onOpenResult(false)");
                    }
                }
            });
        }

        @JavascriptInterface
        public void exportBackup(final String payload, final String fileName) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    pendingBackup = payload;
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("application/json");
                    i.putExtra(Intent.EXTRA_TITLE, fileName);
                    try {
                        startActivityForResult(i, REQ_BACKUP);
                    } catch (Exception e) {
                        pendingBackup = null;
                        callJs("window.onBackupSaved && window.onBackupSaved('fail')");
                    }
                }
            });
        }
    }

    private void callJs(final String js) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (webView != null) webView.evaluateJavascript(js, null);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_FILE) {
            if (filePathCallback == null) return;
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    result = new Uri[n];
                    for (int i = 0; i < n; i++) {
                        result[i] = data.getClipData().getItemAt(i).getUri();
                    }
                } else if (data.getData() != null) {
                    result = new Uri[]{data.getData()};
                }
            }
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
            return;
        }

        if (requestCode == REQ_PICK) {
            if (resultCode != RESULT_OK || data == null) return;
            ArrayList<Uri> uris = new ArrayList<Uri>();
            if (data.getClipData() != null) {
                int n = data.getClipData().getItemCount();
                for (int i = 0; i < n; i++) {
                    Uri u = data.getClipData().getItemAt(i).getUri();
                    if (u != null) uris.add(u);
                }
            } else if (data.getData() != null) {
                uris.add(data.getData());
            }
            JSONArray arr = new JSONArray();
            for (Uri u : uris) {
                try {
                    getContentResolver().takePersistableUriPermission(
                            u, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {
                }
                String name = "";
                try (Cursor c = getContentResolver().query(
                        u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                    if (c != null && c.moveToFirst()) {
                        String s = c.getString(0);
                        if (s != null) name = s;
                    }
                } catch (Exception ignored) {
                }
                String mime = getContentResolver().getType(u);
                if (mime == null) mime = "";
                try {
                    JSONObject o = new JSONObject();
                    o.put("uri", u.toString());
                    o.put("name", name);
                    o.put("mime", mime);
                    arr.put(o);
                } catch (JSONException ignored) {
                }
            }
            callJs("window.onFilesPicked && window.onFilesPicked(" + JSONObject.quote(arr.toString()) + ")");
            return;
        }

        if (requestCode == REQ_BACKUP) {
            String payload = pendingBackup;
            pendingBackup = null;
            if (resultCode != RESULT_OK || data == null || data.getData() == null || payload == null) {
                return; // रद्द कर दिया
            }
            boolean ok = false;
            try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "wt")) {
                if (out != null) {
                    out.write(payload.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                    ok = true;
                }
            } catch (Exception e) {
                ok = false;
            }
            callJs("window.onBackupSaved && window.onBackupSaved('" + (ok ? "ok" : "fail") + "')");
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    @Override
    protected void onPause() {
        // बाहर जाते समय जो लिखा है वो सेव हो जाए
        if (webView != null) {
            webView.evaluateJavascript("window.flushSave && window.flushSave()", null);
        }
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        webView.evaluateJavascript("window.handleBack ? window.handleBack() : false",
                new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                        if (!"true".equals(value)) {
                            finish();
                        }
                    }
                });
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
